#include "stacktype.cpp"
#include "stacktype.h"
#include<stdio.h>
#include <iostream>

using namespace std;

int main()
{
    int count1 = 0;
    int count2 = 0;
    float a= 0, b= 0;
    stacktype<float>MojoJojo;
    stacktype<float>MegaMind;



    float x=1;
    cout<< "Enter Items for MojoJojo: " <<endl;
    while(x>=1)
    {
        cin >>x;
        MojoJojo.Push(x);
        count1++;


    }

    float y=1;
    cout<< "Enter Items MegaMind: " <<endl;
    while(y>=1)
    {
        cin >>y;
        MegaMind.Push(y);
        count2++;


    }

    cout<<endl;

    while(!MojoJojo.IsEmpty())
    {
        a += MojoJojo.Top();
        MojoJojo.Pop();
    }

    cout<< "The Avg Weight of fish of MojoJojo got: "<< a/count1 <<endl;

    cout<<endl;

    while(!MegaMind.IsEmpty())
    {
        b += MegaMind.Top();
        MegaMind.Pop();
    }
    cout<< "The Avg Weight of fish of MegaMind got: "<< b/count2 <<endl;



    cout<<endl;

    if(a>b)
    {
        cout<<"MojoJojo is Win!"<<endl;
    }
    else if(a<b)
    {
        cout<<"MegaMind is Win!"<<endl;
    }
    else
    {
        if(count1>count2)
            cout<<"MojoJojo is Win!"<<endl;
        else
            cout<<"MegaMind is Win!"<<endl;
    }



    return 0;
}
